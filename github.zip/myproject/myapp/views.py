from django.shortcuts import render
from django.http import HttpResponse
from .models import UserModel,engine
from sqlalchemy.orm import sessionmaker



Session=sessionmaker(bind=engine)
session=Session()



def create_user(request):
    name,email,age,grade,roles,school="dee","dee@gmail.com",15,"class-10","student","gsss"
    new_user=UserModel(name=name,email=email,age=age,grade=grade,roles=roles,school=school)
    session.add(new_user)
    session.commit()
    return HttpResponse(f"User(name)added successfully!")


