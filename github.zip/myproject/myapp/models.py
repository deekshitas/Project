

from sqlalchemy.orm import declarative_base
from sqlalchemy import Column,Integer,String,Enum as SQLAlchemyEnum
from enum import Enum

class RoleEnum(Enum):#inhert the role of enum
	STUDENT='Student'
	ADMIN='Admin'
	TEACHER='Teacher'
	PARENT='Parent'

Base=declarative_base()
from sqlalchemy import create_engine
from sqlalchemy.orm import Session,sessionmaker


db_url=f"mysql://root:@127.0.0.1:3306/sample"
print(db_url," .....................")
engine = create_engine(db_url)

Session = sessionmaker(bind=engine)

#Create a Session

session=Session()


class UserModel(Base):
      __tablename__='user'
      id=Column(Integer,primary_key=True)
      name=Column(String(50))
      email=Column(String(100))
      age=Column(Integer)
      grade=Column(String(50)) 
      roles=Column(SQLAlchemyEnum(RoleEnum),nullable=True)
      school=Column(String(50))

